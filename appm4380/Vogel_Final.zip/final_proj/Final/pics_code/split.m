function [low,high]=split(corner,x)
        %here we are trying to organize points into what is on the upper
        %eyelid and lower eyelid


end