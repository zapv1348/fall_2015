%[lxu, lxu_x, lxu_u, lxu_x_x, lxu_x_u, lxu_u_u] = cost_m(x, u, wlt);
%
%  x and u are always required
%  wlt is required if NWL > 0
%
%pronto toolkit
%JH, Jan 2015
