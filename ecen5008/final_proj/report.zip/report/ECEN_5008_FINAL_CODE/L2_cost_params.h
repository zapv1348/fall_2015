/*
 *  L2_cost_params.h
 *
 */

// flying wing

double QD[] = { 1.0, 50.0, 5.0, 1.0 };

double RD[]  = { 0.01, 0.01 };
double RDi[]  = { 100.0, 100.0 };
