/*
 *  QR_params.h
 *
 *    regulator Q & R
 *
 */

// flying wing    v alf omeg th

double Qr[] = {10.0, 50.0, 20.0, 40.0};

double Rr[]  = {0.1, 0.1};
double Rri[] = {10.0, 10.0};
