// #define SECOND_ORDER_DESCENT
#define S_FUNCTION_NAME Prq1_Kv

#include "Prq0_Kv.c"
