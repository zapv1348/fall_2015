%[dx,y, fxu_x,fxu_u, q_fxu_x_x,q_fxu_x_u,q_fxu_u_u] = dynamics_m(x, u, wt, q);
%
%  x and u are always required
%  wt is required if NW > 0
%  q  is required if nlhs > 4
%
%pronto toolkit
%JH, Jan 2015
