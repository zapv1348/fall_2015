% [Qr, Rr] = QR_params_m();
%
%  obtain the regulator Q and R weights specified in QR_params.h