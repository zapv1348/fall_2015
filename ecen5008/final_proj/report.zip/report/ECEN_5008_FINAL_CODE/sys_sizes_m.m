% [NS, NI, NO, NW, NWL, NWC] = sys_sizes_m();
%
%  obtain system size information specified in sys_sizes.h
